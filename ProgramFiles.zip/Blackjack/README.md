# BlackJack Game

This game is a triple-player game which is offline, there can be 2 players and 1 dealer with this.
there is theme functionality, and fullscreen functionality, which does help you concentrate in game more. 
themes are there so for dark theme lovers like me, your eyes won't be in pain because of white theme.
The game's core functions lies in functions_for_blackjack.py. so don't delete it or see the program throwing errors like a kid without the file.
That's it basically, if you have any issues, put a issue, make a pr! don't hesitate at all, no second thoughts, just make it.
And that's it (again)!
