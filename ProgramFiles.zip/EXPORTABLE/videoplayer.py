import tkinter
from tkinter import filedialog
from moviepy.editor import *
THEME_WINDOW_BG, THEME_FOREGROUND = open("theme_config.txt").read().split("\n")
PATH = ""
def openFile():
    global PATH
    PATH = filedialog.askopenfilename(defaultextension=(("MP3 Files", "*.mp3"), ("All Files", "*.")))
    video = VideoFileClip(PATH)
    player = ""
def main(*args):
    root = tkinter.Toplevel(background=THEME_WINDOW_BG)
    _MENU = tkinter.Menu(root, background=THEME_WINDOW_BG, foreground=THEME_WINDOW_BG)
    root.configure(menu=_MENU)
    fileMenu = tkinter.Menu(_MENU, background=THEME_WINDOW_BG, foreground=THEME_FOREGROUND)
    fileMenu.add_command(label="Open a file", command=openFile)
    _MENU.add_cascade(label="File", menu=fileMenu)
    canvas_label = tkinter.Label(root, background=THEME_WINDOW_BG, foreground=THEME_FOREGROUND)
    canvas_label.grid(row=0, column=0)
    root.mainloop()