# fileinspector
This is a simple properties displayer, which obviously displays the properties of a file.
optionally, if my text editor is packaged with it in the same folder, it will have more features such as editing it. 
but, if you want to run it in a isolated environment, it can run as a standalone file, without importing other programs. 
