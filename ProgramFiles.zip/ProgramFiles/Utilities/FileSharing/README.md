# FileSharing
 A way to share files over the network with the IP address and the port needed to work.

This thing is broken off the Notepad program's feature, from there, this amazing feature was copied, from there, added some improvements, and a theme config.
The theme_config.txt has, obviously the theme configuration, being the first line the background, and the latter line being the foreground.
You can change it if it's produced by the program, to any exotic combo you would think of possibly.
That's what I got, thank you for reading this far! :)