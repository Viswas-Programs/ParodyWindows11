import tkinter
def thePointOfNoReturn():
    """ NEW APP! APRIL-MAY 2022 UPDATE! GUI FOR MEMORY HOG CLI"""
    memhg = tkinter.Toplevel()
    memhg.title("Memory hogger GUI")
    tkinter.Label(memhg, text="THIS IS A DANGEROUS PROGRAM! DO YOU WANT TO "
                              "CONTINUE STILL?")

    def death():
        """death"""
        while True:
            tkinter.Toplevel().mainloop(99999)

    yes = tkinter.Button(memhg, text="Yes, Go ahead", command=death)
    yes.pack()
    no = tkinter.Button(memhg, text="No, Please don't", command=memhg.quit)
    no.pack()
    memhg.mainloop()


if __name__ == "__main__":
    thePointOfNoReturn()