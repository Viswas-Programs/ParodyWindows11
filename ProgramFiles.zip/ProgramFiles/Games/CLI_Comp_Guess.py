def play():
    "the game bruh."
    low = 10
    high = 50
    print("Please think of a number between {0} and {1}".format(low, high))
    input("Press ENTER to start")
    guesses = 1
    while True:
        guesses = low + (high - low) // 2
        high_low = input("My guess is {}. Should I guess higher or lower?"
                         "Enter h or l or c, if my guess was correct."
                         .format(guesses))
        if high_low.casefold() == "h":
            # Guess higher. the low end of the range becomes 1 more than of the
            # guess
            low = (guesses + 1)
        elif high_low.casefold() == "l":
            # Guess lower. the higher end of the range becomes 1 lesser than of
            # the guess
            high = (guesses - 1)
        elif high_low == "c":
            print("I got it in {} guesses!!!".format(guesses))
            break
        else:
            print("Answer correctly and properly don't rickroll you bullshit"
                  " asshole!")
        guesses += 1
        print("I Got it in {} guesses".format(guesses))
    print("The program is closed. it would apper that it is not but it is. "
          "you can continue to work on but DONOT CLOSE THIS WINDDOW!")


if __name__ == "__main__":
    play()