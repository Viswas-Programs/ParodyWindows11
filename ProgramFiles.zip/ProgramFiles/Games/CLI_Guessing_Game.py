import random

def play():
    """ play the game bruh!"""
    print("*" * 28)
    print("WELCOME TO THE GUESSING GAME")
    print("*" * 28)
    print(
        "This Game is about guessing the number that is already coded in the "
        "game \nENJOY!!! But don't cheat :)")

    print()
    answer = random.randint(1, 31)

    guess = int(input("Please Guess you number between 1 and 30"))
    while guess < answer or guess > answer:
        print("try again")
        guess = int(input("Please Guess you number between 1 and 30"))
    else:
        print("done")
    print()

    if guess > answer:
        print("Please guess it lower ")
        guess = int(input("Please Guess you number between 1 and 30"))
        if guess == answer:
            print("*" * 24)
            print("You have done it , Champ")
            print("*" * 24)
        else:
            print("Try Again")
    elif guess < answer:
        print("Please guess it higher ")
        guess = int(input("Please Guess you number between 1 and 30"))
        if guess == answer:
            print("*" * 24)
            print("You have done it , Champ")
            print("*" * 24)
        else:
            print("Try Again")
    else:
        print("*" * 33)
        print("CONGRATULATIONS!!!! YOU WON IT!!!")
        print("*" * 33)

    print()
    print("*" * 31)
    print("WELCOME TO THE GUESSING GAME(2)")
    print("*" * 31)
    print(
        "This Game is about guessing the alphabet that is already coded in the "
        "game \nENJOY!!! But don't cheat :)")
    print()
    ANSWERR = "g"

    guess = input("Please Guess you alphabet between a to p")
    print()

    if guess > ANSWERR:
        print("Please guess it lower ")
        guess = int(input("Please Guess you number between a to p"))
        if guess == ANSWERR:
            print("*" * 24)
            print("You have done it , Champ")
            print("*" * 24)
        else:
            print("Try Again")
    elif guess < ANSWERR:
        print("Please guess it higher ")
        guess = int(input("Please Guess you number between a to p"))
        if guess == ANSWERR:
            print("*" * 24)
            print("You have done it , Champ")
            print("*" * 24)
        else:
            print("Try Again")
    else:
        print("*" * 33)
        print("CONGRATULATIONS!!!! YOU WON IT!!!")
        print("*" * 33)
    print("The program is closed. it would apper that it is not but it is. "
            "you can continue to work on but DO NOT CLOSE THIS WINDOW!")
if __name__ == "__main__":
    play()
